package springpj.springmvc.demoSpringMVC.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data //scorciatoie Lombok
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="accounts")
public class Account {
	
	@Id //pk
	@GeneratedValue(strategy=GenerationType.IDENTITY) //ai
 	private Integer id;
	@Column(length=30, nullable=false, unique=true)
	private String username;
	@Column(length=30, nullable=false)
	private String password;
	
}
