package springpj.springmvc.demoSpringMVC.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import springpj.springmvc.demoSpringMVC.model.Account;

@RequestMapping("/Avvio")
@Controller
public class Avvio {
	
	@PostMapping("/takeValues")
	public String takeValues(Account account) {
		System.out.println(account.getUsername());
		System.out.println(account.getPassword());
		return "form";
	}

}
