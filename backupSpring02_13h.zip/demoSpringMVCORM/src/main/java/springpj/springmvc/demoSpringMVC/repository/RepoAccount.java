package springpj.springmvc.demoSpringMVC.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import springpj.springmvc.demoSpringMVC.model.Account;

@Repository
public interface RepoAccount extends JpaRepository<Account, Integer> {
	
	//save(Account account); upsert
	//findById(Integer id);
	//findAll();
	//deleteById(Integer id);
	//existsById(Integer id);
}
