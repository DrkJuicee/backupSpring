package springpj.springmvc.demoSpringMVC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import springpj.springmvc.demoSpringMVC.model.Account;
import springpj.springmvc.demoSpringMVC.repository.RepoAccount;

@RequestMapping("/Avvio")
@Controller
public class Avvio {
	
	@Autowired 
	RepoAccount ra;
	
	@PostMapping("/takeValues")
	public String takeValues(Account account) {
		System.out.println(account.getUsername());
		System.out.println(account.getPassword());
		return "form";
	}
	
	@PostMapping("/upsert")
	public String upsert(Account account) {
		ra.save(account);
		return "form"; //response.sendRedirect("form.html")
	}
	
	@GetMapping("/getAccounts")
	public String getAccounts(Model model) {
		List<Account> accounts = ra.findAll();
		model.addAttribute("accounts", accounts);
		return "tabella";
	}

}
